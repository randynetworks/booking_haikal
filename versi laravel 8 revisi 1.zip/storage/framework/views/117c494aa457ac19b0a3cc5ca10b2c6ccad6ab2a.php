<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Detail Pengajuan R. Rapat <?php echo e($book->topic); ?></h1>
    </div>
    <div class="card shadow mb-4 p-3">
        <div class="form-group mt-3">
            <?php if($book->approved): ?>
                <p class="bg-success text-white p-3">Di Setujui</p>
            <?php else: ?>
                <p class="bg-danger text-white p-3">Belum Di Setujui</p>
            <?php endif; ?>
        </div>
        <div class="from-group">
            <h3>Pengaju</h3>
        </div>
        <div class="form-group">
            <label for="username">Nama Lengkap</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo e($book->username); ?>" disabled>
        </div>
        <div class="form-group">
            <label for="staff_nip">Nomor Induk Staff</label>
            <input type="text" class="form-control" id="staff_nip" name="staff_nip" value="<?php echo e($book->staff_nip); ?>"
                disabled>
        </div>
        <div class="form-group">
            <label for="installation">Instalasi</label>
            <input type="text" class="form-control" id="installation" name="installation"
                value="<?php echo e($book->installation); ?>" disabled>
        </div>
        <div class="from-group mt-3">
            <h3>Pengajuan Ruangan</h3>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="datepicker">Tanggal</label>
                <input type="text" class="form-control" id="datepicker" name="date" value="<?php echo e($book->date); ?>" disabled>
            </div>
            <div class="form-group col-md-6">
                <label for="time">Waktu</label>
                <input type="text" class="form-control" id="time" name="time" value="<?php echo e($book->time); ?>" disabled>
            </div>
        </div>
        <div class="form-group">
            <label for="topic">Topik Rapat</label>
            <input type="text" class="form-control" id="topic" placeholder="Contoh. Kegiatan Meeting Harian" name="topic"
                value="<?php echo e($book->topic); ?>" disabled>
        </div>
        <div class="form-group">
            <label for="entrant">Jumlah Peserta</label>
            <input type="text" class="form-control" id="entrant" name="entrant" value="<?php echo e($book->entrant); ?>" disabled>
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="type_meeting">Jenis Rapat</label>
                <input type="text" class="form-control" id="type_meeting" name="type_meeting"
                    value="<?php echo e($book->type_meeting); ?>" disabled>
            </div>
            <div class="form-group col-md-6">
                <label for="room_id">Ruangan</label>
                <input type="text" class="form-control" id="room_id" name="room_id" value="<?php echo e($book->room->name); ?>"
                    disabled>
            </div>
        </div>
        </form>
        <a href="/" class="btn btn-success">Kembali</a>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randynetworks/Documents/laravelProject/booking_haikal/resources/views/books/show.blade.php ENDPATH**/ ?>