<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Pengajuan Ruangan</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pengajuan Ruangan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Waktu</th>
                            <th scope="col">Topik</th>
                            <th scope="col">Jumlah Peserta</th>
                            <th scope="col">Ruangan</th>
                            <th scope="col">Yang Mengajukan</th>
                            <th scope="col">Status Penyetujuan</th>
                            <th scope="col">Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($book->date); ?></td>
                                <td><?php echo e($book->time); ?></td>
                                <td><?php echo e($book->topic); ?></td>
                                <td><?php echo e($book->entrant); ?></td>
                                <td><?php echo e($book->room->name); ?></td>
                                <td><?php echo e($book->username); ?></td>
                                <?php if($book->approved): ?>
                                    <td class="bg-success text-white">Di Setujui</td>
                                <?php else: ?>
                                    <td class="bg-danger text-white">Belum Di Setujui</td>
                                <?php endif; ?>
                                <td>
                                    <a href="/dashboard/books/<?php echo e($book->id); ?>" class="badge badge-primary">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randynetworks/Documents/laravelProject/booking_haikal/resources/views/dashboard/books/index.blade.php ENDPATH**/ ?>