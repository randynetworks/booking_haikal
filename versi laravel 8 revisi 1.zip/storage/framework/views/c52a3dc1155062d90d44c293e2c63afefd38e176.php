<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Pengajuan</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Detail Pengajuan</h6>
        </div>
        <div class="card-body">
            <?php if($book->approved): ?>
                <p class="bg-success text-white p-3">Di Setujui</p>
            <?php else: ?>
                <p class="bg-danger text-white p-3">Belum Di Setujui</p>
            <?php endif; ?>
            <h3>Pengaju</h3>
            <h5>Nama Lengkap : <?php echo e($book->username); ?></h5>
            <h5>NIP : <?php echo e($book->staff_nip); ?></h5>
            <h5>Installasi : <?php echo e($book->installation); ?></h5>

            <h3 class="mt-3">Pengajuan Ruangan</h3>
            <h5>Tanggal Rapat : <?php echo e($book->date); ?></h5>
            <h5>Waktu Rapat : <?php echo e($book->time); ?></h5>
            <h5>Topik Rapat : <?php echo e($book->topic); ?></h5>
            <h5>Jumlah Peserta : <?php echo e($book->entrant); ?></h5>
            <h5>Jenis Rapat : <?php echo e($book->type_meeting); ?></h5>
            <h5>Ruangan Rapat : <?php echo e($book->room->name); ?></h5>
            </h5>
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button class="btn btn-danger">Hapus</button>
                <a href="/dashboard/books/<?php echo e($book->id); ?>/edit" class="btn btn-primary">Pengesahan Rapat</a>
                <a href="/dashboard/books" class="btn btn-success">Kembali</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randynetworks/Documents/laravelProject/booking_haikal/resources/views/dashboard/books/show.blade.php ENDPATH**/ ?>