<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen User</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data User</h6>
        </div>
        <div class="card-body">
            <form action="/dashboard/users/<?php echo e($user->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="role">Role</label>
                    <input type="hidden" class="form-control" id="role" name="id" value="<?php echo e($user->id); ?>">
                    <select id="role" class="form-control" name="role">
                        <option selected>Pilih...</option>
                        <option value="0">Tidak Aktif</option>
                        <option value="1">Aktif/Admin</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Edit Data</button>
                <a href="/dashboard/users/<?php echo e($user->id); ?>" class="btn btn-success">Kembali</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randynetworks/Documents/laravelProject/booking_haikal/resources/views/dashboard/users/edit.blade.php ENDPATH**/ ?>