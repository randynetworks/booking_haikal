<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Ruangan</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Detail Ruangan</h6>
        </div>
        <div class="card-body">
            <h5>Nama ruangan : <?php echo e($room->name); ?></h5>

            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button class="btn btn-danger">Hapus</button>
                <a href="/dashboard/rooms/<?php echo e($room->id); ?>/edit" class="btn btn-primary">Edit Data</a>
                <a href="/dashboard/rooms" class="btn btn-success">Kembali</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randynetworks/Documents/laravelProject/booking_haikal/resources/views/dashboard/rooms/show.blade.php ENDPATH**/ ?>