<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Daftar Pengajuan R. Rapat</h1>
        <a class="btn btn-success" href="/books/create">Ajukan Ruangan</a>
    </div>
    <div class="card shadow mb-4 p-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pengajuan Ruangan</h6>
        </div>
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Waktu</th>
                    <th scope="col">Topik</th>
                    <th scope="col">Jumlah Peserta</th>
                    <th scope="col">Ruangan</th>
                    <th scope="col">Yang Mengajukan</th>
                    <th scope="col">Status Penyetujuan</th>
                    <th scope="col">Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($book->date); ?></td>
                        <td><?php echo e($book->time); ?></td>
                        <td><?php echo e($book->topic); ?></td>
                        <td><?php echo e($book->entrant); ?></td>
                        <td><?php echo e($book->room->name); ?></td>
                        <td><?php echo e($book->username); ?></td>
                        <?php if($book->approved): ?>
                            <td class="bg-success text-white">Di Setujui</td>
                        <?php else: ?>
                            <td class="bg-danger text-white">Belum Di Setujui</td>
                        <?php endif; ?>
                        <td>
                            <a href="/books/<?php echo e($book->id); ?>" class="badge badge-primary">Detail</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ajukan Pengajuan Ruangan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="p-3" action="/books" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="from-group">
                        <h3>Pengaju</h3>
                    </div>
                    <div class="form-group">
                        <label for="username">Nama Lengkap</label>
                        <input type="text" class="form-control" id="username" name="username">
                    </div>
                    <div class="form-group">
                        <label for="staff_nip">Nomor Induk Staff</label>
                        <input type="text" class="form-control" id="staff_nip" name="staff_nip">
                    </div>
                    <div class="form-group">
                        <label for="installation">Instalasi</label>
                        <input type="text" class="form-control" id="installation" name="installation">
                    </div>
                    <div class="from-group mt-3">
                        <h3>Pengajuan Ruangan</h3>
                    </div>
                    <div class="form-row ">
                        <div class="form-group col-md-6">
                            <label for="datepicker">Tanggal</label>
                            <input type="text" class="form-control" id="datepicker" name="date">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="time-awal">Waktu Awal</label>
                            <input type="text" class="form-control timepicker" id="timepicker" name="time_awal">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="time-akhir">Waktu Akhir</label>
                            <input type="text" class="form-control timepicker" id="timepicker" name="time_akhir">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="topic">Topik Rapat</label>
                        <input type="text" class="form-control" id="topic" placeholder="Contoh. Kegiatan Meeting Harian"
                            name="topic">
                    </div>
                    <div class="form-group">
                        <label for="entrant">Jumlah Peserta</label>
                        <input type="number" class="form-control" id="entrant" name="entrant">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="type_meeting">Jenis Rapat</label>
                            <select id="type_meeting" class="form-control" name="type_meeting">
                                <option selected>Pilih...</option>
                                <option value="Internal">Internal</option>
                                <option value="Eksternal">Eksternal</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="room_id">Ruangan</label>
                            <select id="room_id" class="form-control" name="room_id">
                                <option selected>Pilih...</option>
                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Ajukan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randynetworks/Documents/laravelProject/booking_haikal/resources/views/books/welcome.blade.php ENDPATH**/ ?>